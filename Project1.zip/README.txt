I made the project go from Hash/src/hash341 because my ser file & txt file go into the Hash folder.
All the java source files are in the hash341 folder.