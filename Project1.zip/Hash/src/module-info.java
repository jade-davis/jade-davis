module Hash {
}