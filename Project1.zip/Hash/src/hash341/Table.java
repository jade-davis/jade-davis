
package hash341;
import java.util.ArrayList;

import java.io.Serializable;
import java.lang.Math;

public class Table implements Serializable{
	private ArrayList<City> bucket;
	public int listCount;
	public Hash24 bucketHash;
	public int rehashCount;
	public int secondaryCount;
	
	
	public Table() {
		bucket = new ArrayList<City>(50);
		rehashCount = 0;
		listCount = 0;
		secondaryCount = 0;
	}
	
	public Table add(City tempCity) {
	
		bucket.add(tempCity);
		listCount++;
		return this;
		
	}
	
	
	public City getCity(String cName) {
		if(bucket.size()== 0 || Size() == 0) {
			return null;
		}
		if(Size() == 1 && (!(0 == cName.compareTo(bucket.get(0).name)))){
			return null;
		}
		else if  (Size() == 1) {
			return bucket.get(0);
		}
		else {
			int index = bucketHash.hash(cName) % bucket.size();
			if(!(0 == cName.compareTo(bucket.get(index).name))) {
				return null;
			}
			return bucket.get(index);
		}
			
	}
	
	public void readCity(int index) {
		City tempCity = bucket.get(index);
		System.out.println("Name:" + tempCity.name + " Latitude:" + tempCity.latitude + " Longitude:" + tempCity.longitude);
	}
	
	public void readTable() {
		for(int i = 0; i < bucket.size(); i++) {
			City tempCity = bucket.get(i);
			if(tempCity.name != "") {
				System.out.println("  " + tempCity.name + "(" + tempCity.latitude + ", " + tempCity.longitude + ")");
			}
		}
	}

	public int Size() {
		
		return listCount;
	}

	public void secondaryRehash() {
		
		boolean needRestart = true;
		secondaryCount++;
		ArrayList<City> origTable = copyBucket();
		bucket.clear();
		
		for ( int i = 0; i < ( (int) Math.pow(Size(), 2) ); i++) {
				bucket.add(new City("", 0.0f, 0.0f));
			}
		//System.out.println("size: " + bucket.size());
		//System.out.println("second hash size: " + (int) Math.pow(Size(), 2));
		//going in loop until no collisions
		while(needRestart) {
			//create new hash function and stores it
			bucketHash = new Hash24();
			a: for (City tempCity : origTable) {
				int index = bucketHash.hash(tempCity.name)% ( (int) Math.pow(Size(), 2) );
				
				//checking if empty...
				if(bucket.get(index).name == "") {
					bucket.set(index, tempCity);
					if(tempCity.name == origTable.get(Size()-1).name) {
						needRestart = false;
						break;
					}
				}
				else { //collision has occurred so start over, breaks out of nested loop and clears bucket
					rehashCount++;
					secondaryCount++;
					bucket.clear();
					
					for ( int i = 0; i < ( (int) Math.pow(Size(), 2) ); i++) {
						bucket.add(new City("", 0.0f, 0.0f));
					}
					break a;
				}
		    }
			
		}
	}
	
	public ArrayList<City> copyBucket() {
		ArrayList<City> clonedList = new ArrayList<City>(Size());
	    for (City tempCity : bucket) {
	       clonedList.add(new City(tempCity));
	    }
	    return clonedList;
		
	}
}
