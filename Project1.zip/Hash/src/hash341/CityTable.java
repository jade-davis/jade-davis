package hash341;
import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class CityTable  implements Serializable {
	public   ArrayList<Table> Primary;
	private  int tSize;
	private  Hash24 hashFunction;
	private  int count;
	private int secondaryCount;
	private int maxColsIndex;

	
	public CityTable (String fName, int tsize) {
		tSize = tsize;
		count = 0;
		secondaryCount = 0;
		maxColsIndex =0;
		Primary = new ArrayList<Table>(tsize);
		readtxtFile(fName);
		
		//secondaryHash();
		printInfo();
		
	}
	
	public CityTable(String fName) {
		Primary = new ArrayList<Table>(16000);
		tSize = 16000;
		count = 0;
		secondaryCount = 0;
		readtxtFile(fName);
	}
	

	public City find(String cName) {
		int index =  hashFunction.hash(cName) % 16000;
		//System.out.println("****find index*****: " + index);
		
		//Primary.get(index).readTable();
		
			return Primary.get(index).getCity(cName);
		//}
		
	}
	
	public Table getAtIndex(int index) {
		Table temp = Primary.get(index);
		return temp;
	}
	
	 public void writeToFile(String fName) {
		 try {
	         
	         FileOutputStream out = new FileOutputStream(fName);
	         ObjectOutputStream oout = new ObjectOutputStream(out);
	         
	         
	         oout.writeObject(this);
	        
	        
	         oout.close();

	      
		 } catch (Exception ex) {
	         ex.printStackTrace();
	      }
	        
	 }
	 
	 public CityTable getCityTable() {
		 CityTable newTable = this;
		 return newTable;
		 
	 }
	
	public void readtxtFile(String fName) { // read from txt file and put into hash table
		tSize = 16000;
		count = 0;
		Primary = new ArrayList<Table>(16000);// creating hash table of size n
		for ( int i = 0; i < 16000; i++) {
			Primary.add(new Table());
		}
		
		hashFunction = new Hash24() ; 
		int index;
		Scanner infile = null;
		
		try { infile = new Scanner(new FileReader(fName)); }
		catch (FileNotFoundException e)
		{
			System.out.println("File not found.");
			e.printStackTrace();
			System.exit(0);
		}
		
		// read text file and enter into primary hash table
		while(infile.hasNextLine())
		{
			City tempCity= new City("", 0.0f, 0.0f);
			String Name = infile.nextLine();
			String line = infile.nextLine();
			StringTokenizer tokenizer = new StringTokenizer(line);
			float x = Float.parseFloat(tokenizer.nextToken());
		    float y = Float.parseFloat(tokenizer.nextToken());
			tempCity.name = Name;
			tempCity.latitude = x;
			tempCity.longitude = y;
		    index = hashFunction.hash(Name)% 16000;
		    
		    Primary.set(index, (Primary.get(index).add(tempCity))); 
		    count++;
		}   
		
		secondaryHash();
		
		 
	 }
	
	 public static CityTable readFromFile(String fName) {
		 
		 try { FileInputStream out = new FileInputStream(fName);  
		 	ObjectInputStream oout = new ObjectInputStream(out);   
		 	CityTable temp = (CityTable) oout.readObject();
		 	return temp;
		 }catch (Exception ex){
			ex.printStackTrace();
			
			return null;
		}
		
		
		
	 }

	public void printTable() {
		for (int i = 0; i < 16000; i++) {
			System.out.println("index: " + i);
			Primary.get(i).readTable();
		}
	}
	
	public void printInfo() {
		
		//Initializing cityCount
		int cityCount[] = new int[25];
		for(int i = 0; i < 25; i++) {
			cityCount[i] = 0;
		}
		
		int hashCount[] = new int[21];
		for(int i = 0; i < 21; i++) {
			hashCount[i] = 0;
		}
		
		
		System.out.println("Primary hash table hash function:");
		hashFunction.dump();
		System.out.println();
		
		System.out.println("Primary hash table statistics:");
		System.out.println("  Number of Cities : " + count);
		System.out.println("  Table Size: " + tSize);
		System.out.println("  Max collisions = " + maxCols() );
		
		//getting listCounts from each bucket and adding data to cityCunt array
		for(int i = 0; i < Primary.size(); i++) {
			int amount = Primary.get(i).listCount;
			cityCount[amount]++;
		}
		//printing primary slots with # of cities
		for(int i = 0; i < 25; i++) {
			System.out.println("   # of primary slots with " + i + " cities = " + cityCount[i]);
		}
		System.out.println();
		System.out.println();

		System.out.println(" *** Cities in the slot with the most collisons ***");
		Primary.get(maxColsIndex).readTable();
		
		System.out.println("Secondary hash table statistics:");
		for(int i = 0; i < Primary.size(); i++) {
			int amount = Primary.get(i).secondaryCount;
			hashCount[amount]++;
		}
		
		for(int i = 1; i < 21; i++) {
			System.out.println("   # of secondary hash tables trying " + i + " hash functions = " + hashCount[i]);
		}
		System.out.println();
		System.out.println("Number of secondary hash tables with more than 1 item = " + secondaryCount );
		System.out.println("Average # of hash functions tried = " + rehashAverage());
		

	}
	
	// runs through primary hash table and rehashes collisions 
	public void secondaryHash() {
		//loop through primary table
		for ( int i = 0; i < tSize; i++) {
			//check if there is collision 
			if(Primary.get(i).Size() > 1) {
			
				Primary.get(i).secondaryRehash();
				secondaryCount++;
				//System.out.println("Index " + i + "rehash count: " + Primary.get(i).rehashCount);
			}
			//Primary.get(i).readTable();
		}
		
	}
	
	public float rehashAverage() {
		float rehashAverage = 0;
		int count = 0;
		for(int i = 0; i < tSize; i++) {
			if(Primary.get(i).rehashCount > 0) {
				rehashAverage += Primary.get(i).rehashCount;
				count++;
			}
		}
		return (float)rehashAverage/count;
	}
	
	public int maxCols() {
		int max = 0;
		for(int i = 0; i < tSize; i++) {
			if(Primary.get(i).listCount > 1) {
				if(Primary.get(i).listCount > max) {
					maxColsIndex = i;
					max = Primary.get(i).listCount;
				}
			}
		}
		return max;
	}
}
