package hash341;
import java.util.Scanner;

public class Program2 {
	static Scanner sc = new Scanner(System.in);
	public static void printCity(City aCity) {
	      if (aCity == null) {
	         System.out.println("Could not find") ;
	      } else {
	         System.out.println( aCity.name + " (" + aCity.latitude + "," + aCity.longitude + ")" ) ;
	         System.out.println("http://www.google.com/maps?z=10&q=" + aCity.latitude + "," + aCity.longitude);
	      }
	   }
	
	public static void main(String args[])
	{
	      CityTable USA ;
	      

	      USA = CityTable.readFromFile("US_Cities_LL.ser") ;
				

		System.out.println("Creating Hash Table of US_Cities_LL.ser") ;
		//USA.printTable();
		
		while(true) {
			System.out.println("Enter City, State (or 'quit') : ");
			String city =  sc.nextLine();
			if(0 == city.compareTo("quit")) {
				break;
			}
			else {
				printCity( USA.find(city) ) ;
				
			}
			
		}
	}

}
