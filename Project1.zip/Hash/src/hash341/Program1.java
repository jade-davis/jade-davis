package hash341;
import java.util.Scanner;

public class Program1 {
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String args[])
	{
		
				

		//System.out.println("Creating Hash Table of list US_Cities_LL.txt") ;
		CityTable USA= new CityTable("US_Cities_LL.txt" , 16000);
		//USA.printTable();
		USA.writeToFile("US_Cities_LL.ser");
		
		
		
	}
		
		
	}

