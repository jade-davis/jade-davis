package hash341;

import java.io.Serializable;

public class City implements Serializable{
	public String name; 
	public float latitude; 
	public float longitude;
	
	public City(String Name, float Latitude, float Longitude) {
		name = Name;
		latitude = Latitude;
		longitude = Longitude;
	}

	public City(City tempCity) {
		name = tempCity.name;
		latitude = tempCity.latitude;
		longitude = tempCity.longitude;
	}

	public String getName() {
		return name;
	}
	
	public float getLat() {
		return latitude;
	}
	public float getLong() {
		return longitude;
	}
	
	public void printCity() {
		System.out.println("Name: " + name + "Lat: " + latitude + "Long: " + longitude);
	}
}
